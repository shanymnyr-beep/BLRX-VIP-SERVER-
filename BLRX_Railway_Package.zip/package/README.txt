════════════════════════════════════════════════════════════
   BLRX VIP — دليل الإعداد الكامل على Railway.app
════════════════════════════════════════════════════════════

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  الخطوة 1 — إنشاء حساب Railway
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. افتح: https://railway.app
2. اضغط "Login" ← سجّل بـ GitHub
   (إذا ما عندك GitHub سجّل في github.com مجاناً)


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  الخطوة 2 — إنشاء قاعدة بيانات MySQL
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. اضغط "New Project"
2. اختر "Deploy MySQL"
3. انتظر دقيقة حتى يُنشأ
4. اضغط على MySQL ← اضغط "Variables"
5. ستجد:
   MYSQLHOST / MYSQLUSER / MYSQLPASSWORD / MYSQLDATABASE / MYSQLPORT
   ✅ احفظها


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  الخطوة 3 — تشغيل install.sql
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. في Railway اضغط MySQL ← "Query"
2. انسخ محتوى install.sql والصقه
3. اضغط Run
   ✅ ينشئ جدولي: keys و verify_log


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  الخطوة 4 — رفع ملفات PHP على GitHub
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. روح github.com ← أنشئ Repository جديد اسمه "blrx-server"
2. ارفع هذه الملفات من مجلد server/:
   - config.php
   - db.php
   - verify.php
   - index.php
   - install.sql
3. في Railway ← "New Service" ← "GitHub Repo"
4. اختر blrx-server
   ✅ Railway يبني تلقائياً


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  الخطوة 5 — ربط MySQL بالـ PHP Service
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. افتح PHP Service ← "Variables"
2. اضغط "Add Variable Reference"
3. أضف كل المتغيرات من MySQL service:
   MYSQLHOST, MYSQLUSER, MYSQLPASSWORD, MYSQLDATABASE, MYSQLPORT


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  الخطوة 6 — الحصول على رابط السيرفر
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. PHP Service ← "Settings" ← "Generate Domain"
2. ستحصل على رابط مثل:
   https://blrx-server-production.up.railway.app

3. اختبر في المتصفح:
   https://blrx-server-production.up.railway.app/verify.php
   يجب أن يظهر: {"success":false,"code":"METHOD_NOT_ALLOWED"}  ✅


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  الخطوة 7 — تحديث MAYUR_LOGIN.h
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
في cpp/MAYUR_LOGIN.h غيّر هذا السطر:

  #define LOGIN_SERVER_URL "https://YOUR_APP.up.railway.app/verify.php"

إلى رابطك:

  #define LOGIN_SERVER_URL "https://blrx-server-production.up.railway.app/verify.php"

✅ ابنِ المود وجرّب


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  الخطوة 8 — لوحة إدارة المفاتيح
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
افتح في المتصفح:
  https://blrx-server-production.up.railway.app/

كلمة المرور الافتراضية: BLRX/2010

من اللوحة تقدر:
  - إنشاء مفاتيح بكميات مختلفة
  - تحديد المدة: 1 / 3 / 7 / 15 / 30 يوم
  - إلغاء أو حذف المفاتيح
  - رؤية إحصائيات الاستخدام


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  قائمة الملفات
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
server/
├── config.php    ← إعدادات DB تلقائية من Railway
├── db.php        ← اتصال قاعدة البيانات
├── verify.php    ← API التحقق
├── index.php     ← لوحة الإدارة الكاملة
└── install.sql   ← إنشاء الجداول (مرة واحدة)

cpp/
└── MAYUR_LOGIN.h ← غيّر LOGIN_SERVER_URL فقط
