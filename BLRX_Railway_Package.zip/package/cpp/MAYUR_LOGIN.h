// ═══════════════════════════════════════════════════════════════════
//  MAYUR_LOGIN.h  —  BLRX || VIP  Login System
//  HTTP via JNI HttpURLConnection (no libcurl)
//  FIX v3: User-Agent + JSON flat parse + race condition + all crashes
// ═══════════════════════════════════════════════════════════════════
#pragma once

#include <string>
#include <atomic>
#include <mutex>
#include <thread>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <android/log.h>
#include <jni.h>
#include "imgui/imgui.h"

#define LOGIN_TAG "BLRX_LOGIN"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOGIN_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOGIN_TAG, __VA_ARGS__)

#define LOGIN_SERVER_URL "https://blrxvipxmodt.xo.je/verify.php"

// ── jvm معرّف مرة واحدة ──────────────────────────────────────────
#ifndef JVM_DEFINED
#define JVM_DEFINED
JavaVM* jvm = nullptr;
#endif

// ════════════════════════════════════════════════════════════════════
//  رسائل الخطأ — English فقط
// ════════════════════════════════════════════════════════════════════
static const char* getErrorMessage(const char* code) {
    if (!code)                                   return "[ Unknown Error ]";
    if (strcmp(code, "INVALID_KEY")        == 0) return "[ Invalid Key ]";
    if (strcmp(code, "EXPIRED_KEY")        == 0) return "[ Key Expired ]";
    if (strcmp(code, "WRONG_DEVICE")       == 0) return "[ Wrong Device ]";
    if (strcmp(code, "RATE_LIMIT")         == 0) return "[ Try Again Later ]";
    if (strcmp(code, "METHOD_NOT_ALLOWED") == 0) return "[ Server Error ]";
    if (strcmp(code, "NET_ERROR")          == 0) return "[ No Internet ]";
    if (strcmp(code, "TIMEOUT")            == 0) return "[ Connection Timeout ]";
    return "[ Verification Failed ]";
}

// ════════════════════════════════════════════════════════════════════
//  متغيرات الحالة
// ════════════════════════════════════════════════════════════════════
namespace LoginState {
    std::atomic<bool> g_IsLoggedIn  { false };
    std::atomic<bool> g_IsChecking  { false };
    std::atomic<bool> g_IsPasting   { false };
    std::atomic<bool> g_ClipReady   { false };
    std::mutex        g_Mtx;
    char              g_InputKey[64] = { 0 };
    std::string       g_StatusMsg    = "";
    bool              g_StatusOK     = false;
    std::string       g_Plan         = "";
    int               g_DaysLeft     = 0;
    std::string       g_ClipPending  = "";
}

// ════════════════════════════════════════════════════════════════════
//  JNI Helper — attach/detach آمن
// ════════════════════════════════════════════════════════════════════
struct JNIScope {
    JNIEnv* env   = nullptr;
    bool attached = false;
    JNIScope() {
        if (!jvm) return;
        int st = jvm->GetEnv((void**)&env, JNI_VERSION_1_6);
        if (st == JNI_EDETACHED) {
            jvm->AttachCurrentThread(&env, nullptr);
            attached = true;
        }
    }
    ~JNIScope() {
        if (attached && jvm) jvm->DetachCurrentThread();
    }
    bool ok() { return env != nullptr; }
};

// ════════════════════════════════════════════════════════════════════
//  Device ID
// ════════════════════════════════════════════════════════════════════
static std::string g_DeviceId;

static std::string getDeviceId() {
    if (!g_DeviceId.empty()) return g_DeviceId;
    JNIScope jni;
    if (!jni.ok()) { g_DeviceId = "DEV_UNKNOWN"; return g_DeviceId; }
    JNIEnv* env = jni.env;

    jclass atClass = env->FindClass("android/app/ActivityThread");
    if (!atClass) { g_DeviceId = "DEV_NOCLZ"; return g_DeviceId; }

    jmethodID curApp = env->GetStaticMethodID(atClass,
        "currentApplication", "()Landroid/app/Application;");
    if (!curApp) { g_DeviceId = "DEV_NOMTH"; return g_DeviceId; }

    jobject app = env->CallStaticObjectMethod(atClass, curApp);
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        g_DeviceId = "DEV_EXC1";
        return g_DeviceId;
    }
    if (!app) { g_DeviceId = "DEV_NOAPP"; return g_DeviceId; }

    jclass ctxClass = env->FindClass("android/content/Context");
    if (!ctxClass) { g_DeviceId = "DEV_NOCTX"; return g_DeviceId; }

    jmethodID getCR = env->GetMethodID(ctxClass,
        "getContentResolver", "()Landroid/content/ContentResolver;");
    if (!getCR) { g_DeviceId = "DEV_NOCR"; return g_DeviceId; }

    jobject cr = env->CallObjectMethod(app, getCR);
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        g_DeviceId = "DEV_EXC2";
        return g_DeviceId;
    }
    if (!cr) { g_DeviceId = "DEV_NULLCR"; return g_DeviceId; }

    jclass secClass = env->FindClass("android/provider/Settings$Secure");
    if (!secClass) { g_DeviceId = "DEV_NOSEC"; return g_DeviceId; }

    jmethodID getStr = env->GetStaticMethodID(secClass, "getString",
        "(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;");
    if (!getStr) { g_DeviceId = "DEV_NOSTR"; return g_DeviceId; }

    jstring keyStr = env->NewStringUTF("android_id");
    auto result = (jstring)env->CallStaticObjectMethod(secClass, getStr, cr, keyStr);
    env->DeleteLocalRef(keyStr);

    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        g_DeviceId = "DEV_EXC3";
        return g_DeviceId;
    }

    if (result) {
        const char* id = env->GetStringUTFChars(result, nullptr);
        g_DeviceId = id ? id : "DEV_EMPTY";
        env->ReleaseStringUTFChars(result, id);
        env->DeleteLocalRef(result);
    } else {
        g_DeviceId = "DEV_FALLBACK";
    }
    LOGI("DeviceId: %s", g_DeviceId.c_str());
    return g_DeviceId;
}

// ════════════════════════════════════════════════════════════════════
//  Clipboard — يعمل في thread منفصل تماماً لمنع التعليق
// ════════════════════════════════════════════════════════════════════
static void fetchClipboardAsync() {
    JNIScope jni;
    if (!jni.ok()) {
        LoginState::g_IsPasting.store(false);
        return;
    }
    JNIEnv* env = jni.env;
    std::string out;

    jclass atClass = env->FindClass("android/app/ActivityThread");
    if (!atClass) { LoginState::g_IsPasting.store(false); return; }

    jmethodID curApp = env->GetStaticMethodID(atClass,
        "currentApplication", "()Landroid/app/Application;");
    if (!curApp) { LoginState::g_IsPasting.store(false); return; }

    jobject app = env->CallStaticObjectMethod(atClass, curApp);
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        LoginState::g_IsPasting.store(false);
        return;
    }
    if (!app) { LoginState::g_IsPasting.store(false); return; }

    jclass ctxClass = env->FindClass("android/content/Context");
    if (!ctxClass) { LoginState::g_IsPasting.store(false); return; }

    jmethodID getSvc = env->GetMethodID(ctxClass, "getSystemService",
        "(Ljava/lang/String;)Ljava/lang/Object;");
    if (!getSvc) { LoginState::g_IsPasting.store(false); return; }

    jstring svcName = env->NewStringUTF("clipboard");
    jobject clipMgr = env->CallObjectMethod(app, getSvc, svcName);
    env->DeleteLocalRef(svcName);

    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        LoginState::g_IsPasting.store(false);
        return;
    }

    if (clipMgr) {
        jclass cmClass = env->GetObjectClass(clipMgr);
        if (cmClass) {
            jmethodID getText = env->GetMethodID(cmClass, "getText",
                "()Ljava/lang/CharSequence;");
            if (getText) {
                jobject csObj = env->CallObjectMethod(clipMgr, getText);
                if (env->ExceptionCheck()) { env->ExceptionClear(); }
                else if (csObj) {
                    jclass csClass = env->GetObjectClass(csObj);
                    if (csClass) {
                        jmethodID toString = env->GetMethodID(csClass,
                            "toString", "()Ljava/lang/String;");
                        if (toString) {
                            auto jstr = (jstring)env->CallObjectMethod(csObj, toString);
                            if (jstr) {
                                const char* txt = env->GetStringUTFChars(jstr, nullptr);
                                if (txt) out = txt;
                                env->ReleaseStringUTFChars(jstr, txt);
                                env->DeleteLocalRef(jstr);
                            }
                        }
                    }
                }
            }
        }
    }

    // تنظيف newlines
    out.erase(std::remove(out.begin(), out.end(), '\n'), out.end());
    out.erase(std::remove(out.begin(), out.end(), '\r'), out.end());
    // trim spaces
    while (!out.empty() && out.front() == ' ') out.erase(out.begin());
    while (!out.empty() && out.back()  == ' ') out.pop_back();

    {
        std::lock_guard<std::mutex> lk(LoginState::g_Mtx);
        LoginState::g_ClipPending = out;
    }
    LoginState::g_ClipReady.store(true);
    LoginState::g_IsPasting.store(false);
}

// ════════════════════════════════════════════════════════════════════
//  JSON Validator — يتحقق أن الرد JSON حقيقي
// ════════════════════════════════════════════════════════════════════
static bool isValidJsonResponse(const std::string& r) {
    if (r.empty()) return false;
    size_t start = r.find_first_not_of(" \t\r\n");
    return (start != std::string::npos && r[start] == '{');
}

// ════════════════════════════════════════════════════════════════════
//  HTTP POST عبر JNI HttpURLConnection — بدون libcurl
// ════════════════════════════════════════════════════════════════════
static std::string httpPost(const std::string& url,
                             const std::string& jsonBody) {
    JNIScope jni;
    if (!jni.ok()) { LOGE("JNI not available"); return ""; }
    JNIEnv* env = jni.env;
    std::string result;

    jclass urlClass = env->FindClass("java/net/URL");
    if (!urlClass) { LOGE("URL class not found"); return ""; }

    jmethodID urlInit = env->GetMethodID(urlClass, "<init>",
        "(Ljava/lang/String;)V");
    jstring jUrl = env->NewStringUTF(url.c_str());
    jobject urlObj = env->NewObject(urlClass, urlInit, jUrl);
    env->DeleteLocalRef(jUrl);
    if (!urlObj) { LOGE("URL object failed"); return ""; }

    jmethodID openConn = env->GetMethodID(urlClass, "openConnection",
        "()Ljava/net/URLConnection;");
    jobject connObj = env->CallObjectMethod(urlObj, openConn);
    env->DeleteLocalRef(urlObj);
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        LOGE("openConnection threw exception");
        return "";
    }
    if (!connObj) { LOGE("openConnection failed"); return ""; }

    jclass httpClass = env->FindClass("java/net/HttpURLConnection");
    if (!httpClass) {
        LOGE("HttpURLConnection class not found");
        env->DeleteLocalRef(connObj);
        return "";
    }

    jmethodID setMethod  = env->GetMethodID(httpClass, "setRequestMethod", "(Ljava/lang/String;)V");
    jmethodID setDoOut   = env->GetMethodID(httpClass, "setDoOutput", "(Z)V");
    jmethodID setReqProp = env->GetMethodID(httpClass, "setRequestProperty", "(Ljava/lang/String;Ljava/lang/String;)V");
    jmethodID setConTO   = env->GetMethodID(httpClass, "setConnectTimeout", "(I)V");
    jmethodID setReadTO  = env->GetMethodID(httpClass, "setReadTimeout", "(I)V");
    jmethodID disc       = env->GetMethodID(httpClass, "disconnect", "()V");

    jstring postStr = env->NewStringUTF("POST");
    env->CallVoidMethod(connObj, setMethod, postStr);
    env->DeleteLocalRef(postStr);
    env->CallVoidMethod(connObj, setDoOut, JNI_TRUE);
    env->CallVoidMethod(connObj, setConTO, (jint)5000);
    env->CallVoidMethod(connObj, setReadTO, (jint)5000);

    // ── Headers ─────────────────────────────────────────────────
    // Content-Type
    jstring hKey = env->NewStringUTF("Content-Type");
    jstring hVal = env->NewStringUTF("application/json; charset=UTF-8");
    env->CallVoidMethod(connObj, setReqProp, hKey, hVal);
    env->DeleteLocalRef(hKey);
    env->DeleteLocalRef(hVal);

    // ✅ FIX: User-Agent — InfinityFree يحجب الطلبات بدونه
    jstring uaKey = env->NewStringUTF("User-Agent");
    jstring uaVal = env->NewStringUTF(
        "Mozilla/5.0 (Linux; Android 10; Mobile) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Mobile Safari/537.36");
    env->CallVoidMethod(connObj, setReqProp, uaKey, uaVal);
    env->DeleteLocalRef(uaKey);
    env->DeleteLocalRef(uaVal);

    // Accept
    jstring acKey = env->NewStringUTF("Accept");
    jstring acVal = env->NewStringUTF("application/json");
    env->CallVoidMethod(connObj, setReqProp, acKey, acVal);
    env->DeleteLocalRef(acKey);
    env->DeleteLocalRef(acVal);
    // ────────────────────────────────────────────────────────────

    // ✅ FIX: exception check على getOutputStream
    jmethodID getOS = env->GetMethodID(httpClass, "getOutputStream", "()Ljava/io/OutputStream;");
    jobject osObj = env->CallObjectMethod(connObj, getOS);
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        LOGE("getOutputStream threw exception");
        env->CallVoidMethod(connObj, disc);
        env->DeleteLocalRef(connObj);
        return "";
    }
    if (!osObj) {
        LOGE("getOutputStream null");
        env->CallVoidMethod(connObj, disc);
        env->DeleteLocalRef(connObj);
        return "";
    }

    jclass    osClass = env->FindClass("java/io/OutputStream");
    jmethodID osWrite = env->GetMethodID(osClass, "write", "([B)V");
    jmethodID osFlush = env->GetMethodID(osClass, "flush", "()V");
    jmethodID osClose = env->GetMethodID(osClass, "close", "()V");

    jbyteArray bodyArr = env->NewByteArray((jsize)jsonBody.size());
    env->SetByteArrayRegion(bodyArr, 0, (jsize)jsonBody.size(),
        (const jbyte*)jsonBody.c_str());
    env->CallVoidMethod(osObj, osWrite, bodyArr);
    if (env->ExceptionCheck()) { env->ExceptionClear(); LOGE("write failed"); }
    env->CallVoidMethod(osObj, osFlush);
    env->CallVoidMethod(osObj, osClose);
    env->DeleteLocalRef(bodyArr);
    env->DeleteLocalRef(osObj);

    // ✅ FIX: تحقق من response code قبل getInputStream
    jmethodID getCode = env->GetMethodID(httpClass, "getResponseCode", "()I");
    jint responseCode = 0;
    if (getCode) {
        responseCode = env->CallIntMethod(connObj, getCode);
        if (env->ExceptionCheck()) {
            env->ExceptionClear();
            responseCode = 0;
        }
    }
    LOGI("HTTP response code: %d", (int)responseCode);

    // ✅ FIX: اختر stream صحيح بناءً على response code
    jmethodID streamMethod;
    if (responseCode >= 200 && responseCode < 300) {
        streamMethod = env->GetMethodID(httpClass,
            "getInputStream", "()Ljava/io/InputStream;");
    } else {
        streamMethod = env->GetMethodID(httpClass,
            "getErrorStream", "()Ljava/io/InputStream;");
    }

    jobject isObj = env->CallObjectMethod(connObj, streamMethod);
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        LOGE("stream threw exception (code=%d)", (int)responseCode);
        env->CallVoidMethod(connObj, disc);
        env->DeleteLocalRef(connObj);
        return "";
    }
    if (!isObj) {
        LOGE("stream is null for code %d", (int)responseCode);
        env->CallVoidMethod(connObj, disc);
        env->DeleteLocalRef(connObj);
        return "";
    }

    jclass    isrClass = env->FindClass("java/io/InputStreamReader");
    jmethodID isrInit  = env->GetMethodID(isrClass, "<init>",
        "(Ljava/io/InputStream;)V");
    jobject isrObj = env->NewObject(isrClass, isrInit, isObj);
    if (!isrObj) {
        LOGE("InputStreamReader failed");
        env->CallVoidMethod(connObj, disc);
        env->DeleteLocalRef(connObj);
        return "";
    }

    jclass    brClass  = env->FindClass("java/io/BufferedReader");
    jmethodID brInit   = env->GetMethodID(brClass, "<init>",
        "(Ljava/io/Reader;)V");
    jobject brObj = env->NewObject(brClass, brInit, isrObj);
    if (!brObj) {
        LOGE("BufferedReader failed");
        env->CallVoidMethod(connObj, disc);
        env->DeleteLocalRef(connObj);
        return "";
    }

    jmethodID readLine = env->GetMethodID(brClass, "readLine",
        "()Ljava/lang/String;");

    while (true) {
        auto line = (jstring)env->CallObjectMethod(brObj, readLine);
        if (env->ExceptionCheck()) { env->ExceptionClear(); break; }
        if (!line) break;
        const char* s = env->GetStringUTFChars(line, nullptr);
        if (s) result += s;
        env->ReleaseStringUTFChars(line, s);
        env->DeleteLocalRef(line);
    }

    env->CallVoidMethod(connObj, disc);
    env->DeleteLocalRef(connObj);

    LOGI("HTTP response: %s", result.c_str());
    return result;
}

// ════════════════════════════════════════════════════════════════════
//  JSON Parser بسيط
// ════════════════════════════════════════════════════════════════════
static std::string jsonGetString(const std::string& j,
                                  const std::string& key) {
    std::string s = "\"" + key + "\":\"";
    auto p1 = j.find(s);
    if (p1 == std::string::npos) return "";
    p1 += s.size();
    auto p2 = j.find("\"", p1);
    if (p2 == std::string::npos) return "";
    return j.substr(p1, p2 - p1);
}

static int jsonGetInt(const std::string& j, const std::string& key) {
    std::string s = "\"" + key + "\":";
    auto p1 = j.find(s);
    if (p1 == std::string::npos) return 0;
    p1 += s.size();
    try { return std::stoi(j.substr(p1, 6)); }
    catch (...) { return 0; }
}

// ════════════════════════════════════════════════════════════════════
//  دالة التحقق — thread منفصل
// ════════════════════════════════════════════════════════════════════
static void doLoginRequest(std::string keyStr, std::string deviceId) {
    LOGI("Checking key: %s", keyStr.c_str());

    char body[256];
    snprintf(body, sizeof(body),
        "{\"key\":\"%s\",\"deviceId\":\"%s\"}",
        keyStr.c_str(), deviceId.c_str());

    std::string response = httpPost(LOGIN_SERVER_URL, body);

    bool        success = false;
    std::string errCode = "NET_ERROR";

    if (response.empty()) {
        // ✅ FIX: timeout رسالة منفصلة
        errCode = "TIMEOUT";
    }
    else if (!isValidJsonResponse(response)) {
        // ✅ FIX: السيرفر رجع HTML أو نص غير JSON
        LOGE("Non-JSON response: %.100s", response.c_str());
        errCode = "NET_ERROR";
    }
    else if (response.find("\"success\":true") != std::string::npos) {
        success = true;
        // ✅ FIX: plan و daysLeft الآن في الجذر مباشرة (بعد إصلاح verify.php)
        std::lock_guard<std::mutex> lk(LoginState::g_Mtx);
        LoginState::g_Plan     = jsonGetString(response, "plan");
        LoginState::g_DaysLeft = jsonGetInt(response, "daysLeft");
    }
    else {
        errCode = jsonGetString(response, "code");
        if (errCode.empty()) errCode = "INVALID_KEY";
    }

    {
        std::lock_guard<std::mutex> lk(LoginState::g_Mtx);
        LoginState::g_StatusMsg = success
            ? "[ Login Success ]"
            : getErrorMessage(errCode.c_str());
        LoginState::g_StatusOK = success;
    }

    LoginState::g_IsLoggedIn.store(success);
    LoginState::g_IsChecking.store(false);
    LOGI("Result: %s", success ? "OK" : errCode.c_str());
}

// ════════════════════════════════════════════════════════════════════
//  رسم واجهة Login
// ════════════════════════════════════════════════════════════════════
static void DrawLoginWindow(int screenW, int screenH) {
    if (LoginState::g_IsLoggedIn.load()) return;

    // ✅ تطبيق نص الحافظة عند جهوزيته — في UI thread بأمان
    if (LoginState::g_ClipReady.load()) {
        LoginState::g_ClipReady.store(false);
        std::lock_guard<std::mutex> lk(LoginState::g_Mtx);
        if (!LoginState::g_ClipPending.empty()) {
            snprintf(LoginState::g_InputKey,
                sizeof(LoginState::g_InputKey),
                "%s", LoginState::g_ClipPending.c_str());
            LoginState::g_StatusMsg = "[ Pasted ]";
            LoginState::g_StatusOK  = true;
            LoginState::g_ClipPending.clear();
        }
    }

    const float WIN_W = 520.0f;
    const float WIN_H = 340.0f;

    ImGui::SetNextWindowPos(
        ImVec2((screenW - WIN_W) * 0.5f, (screenH - WIN_H) * 0.5f),
        ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(WIN_W, WIN_H), ImGuiCond_Always);
    ImGui::SetNextWindowBgAlpha(0.97f);

    ImGui::PushStyleColor(ImGuiCol_WindowBg,
        ImVec4(0.04f, 0.04f, 0.08f, 1.00f));
    ImGui::PushStyleColor(ImGuiCol_Border,
        ImVec4(0.50f, 0.20f, 0.90f, 1.00f));
    ImGui::PushStyleColor(ImGuiCol_FrameBg,
        ImVec4(0.10f, 0.08f, 0.18f, 1.00f));
    ImGui::PushStyleColor(ImGuiCol_FrameBgHovered,
        ImVec4(0.18f, 0.12f, 0.30f, 1.00f));
    ImGui::PushStyleColor(ImGuiCol_Button,
        ImVec4(0.30f, 0.10f, 0.70f, 1.00f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered,
        ImVec4(0.45f, 0.15f, 0.90f, 1.00f));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive,
        ImVec4(0.20f, 0.07f, 0.55f, 1.00f));
    ImGui::PushStyleColor(ImGuiCol_Text,
        ImVec4(1.00f, 1.00f, 1.00f, 1.00f));

    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding,   14.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding,    8.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 2.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(10, 12));

    ImGuiWindowFlags flags =
        ImGuiWindowFlags_NoMove          |
        ImGuiWindowFlags_NoResize        |
        ImGuiWindowFlags_NoCollapse      |
        ImGuiWindowFlags_NoSavedSettings |
        ImGuiWindowFlags_NoTitleBar      |
        ImGuiWindowFlags_NoBringToFrontOnFocus;

    if (ImGui::Begin("##LoginWnd", nullptr, flags)) {

        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec2 wp = ImGui::GetWindowPos();
        ImVec2 ws = ImGui::GetWindowSize();

        // خلفية متوهجة
        float t = (float)ImGui::GetTime();
        dl->AddRectFilled(wp,
            ImVec2(wp.x + ws.x, wp.y + ws.y),
            ImGui::GetColorU32(ImVec4(0.4f, 0.1f, 0.9f,
                0.08f + 0.04f * sinf(t * 2.0f))), 14.0f);

        // Header
        float headerH = 52.0f;
        dl->AddRectFilled(wp,
            ImVec2(wp.x + ws.x, wp.y + headerH),
            ImGui::GetColorU32(ImVec4(0.10f, 0.04f, 0.25f, 1.0f)), 14.0f);

        const char* title = "BLRX  ||  VIP";
        ImVec2 tSz = ImGui::CalcTextSize(title);
        dl->AddText(nullptr, 26.0f,
            ImVec2(wp.x + (ws.x - tSz.x) * 0.5f, wp.y + 13.0f),
            ImGui::GetColorU32(ImVec4(0.80f, 0.40f, 1.00f, 1.0f)), title);

        dl->AddLine(
            ImVec2(wp.x + 20, wp.y + headerH),
            ImVec2(wp.x + ws.x - 20, wp.y + headerH),
            ImGui::GetColorU32(ImVec4(0.5f, 0.2f, 0.9f, 0.8f)), 1.5f);

        ImGui::SetCursorPosY(headerH + 18.0f);

        // Enter Key label
        ImGui::SetCursorPosX(30.0f);
        ImGui::TextColored(
            ImVec4(0.70f, 0.70f, 0.90f, 1.0f), "Enter Key :");

        // Input box
        ImGui::SetCursorPosX(30.0f);
        ImGui::SetNextItemWidth(WIN_W - 60.0f);
        bool enterPressed = false;
        {
            std::lock_guard<std::mutex> lk(LoginState::g_Mtx);
            ImGuiInputTextFlags itf = ImGuiInputTextFlags_EnterReturnsTrue;
            if (LoginState::g_IsChecking.load())
                itf |= ImGuiInputTextFlags_ReadOnly;
            enterPressed = ImGui::InputTextWithHint(
                "##key", "Enter your key here...",
                LoginState::g_InputKey,
                sizeof(LoginState::g_InputKey), itf);
        }

        ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 14.0f);

        float btnW    = (WIN_W - 60.0f - 12.0f) * 0.5f;
        bool  checking = LoginState::g_IsChecking.load();
        bool  pasting  = LoginState::g_IsPasting.load();

        // زر LOGIN
        ImGui::SetCursorPosX(30.0f);
        if (checking) {
            ImGui::PushStyleColor(ImGuiCol_Button,
                ImVec4(0.20f, 0.20f, 0.20f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered,
                ImVec4(0.20f, 0.20f, 0.20f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive,
                ImVec4(0.20f, 0.20f, 0.20f, 1.0f));
        }
        bool loginClicked = ImGui::Button(
            checking ? "[ Checking... ]" : "LOGIN",
            ImVec2(btnW, 52.0f));
        if (checking) ImGui::PopStyleColor(3);

        // زر Paste
        ImGui::SameLine(0, 12.0f);
        ImGui::PushStyleColor(ImGuiCol_Button,
            ImVec4(0.10f, 0.20f, 0.35f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered,
            ImVec4(0.15f, 0.35f, 0.60f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive,
            ImVec4(0.08f, 0.15f, 0.28f, 1.0f));
        bool pasteClicked = ImGui::Button(
            pasting ? "[ ... ]" : "[ Paste ]",
            ImVec2(btnW, 52.0f));
        ImGui::PopStyleColor(3);

        // رسالة الحالة
        ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10.0f);
        {
            std::lock_guard<std::mutex> lk(LoginState::g_Mtx);
            if (!LoginState::g_StatusMsg.empty()) {
                ImVec4 col = LoginState::g_StatusOK
                    ? ImVec4(0.30f, 1.00f, 0.30f, 1.0f)
                    : ImVec4(1.00f, 0.30f, 0.30f, 1.0f);
                ImVec2 sz = ImGui::CalcTextSize(
                    LoginState::g_StatusMsg.c_str());
                ImGui::SetCursorPosX((WIN_W - sz.x) * 0.5f);
                ImGui::TextColored(col, "%s",
                    LoginState::g_StatusMsg.c_str());
            }
        }

        // ── Paste — thread منفصل لمنع التعليق ────────────────────
        if (pasteClicked && !pasting) {
            LoginState::g_IsPasting.store(true);
            std::thread([]() {
                fetchClipboardAsync();
            }).detach();
        }

        // ── ✅ FIX: LOGIN handler — compare_exchange يمنع race condition ──
        if (loginClicked || enterPressed) {
            bool expected = false;
            if (LoginState::g_IsChecking.compare_exchange_strong(expected, true)) {
                std::string key;
                {
                    std::lock_guard<std::mutex> lk(LoginState::g_Mtx);
                    key = LoginState::g_InputKey;
                }
                while (!key.empty() && key.front() == ' ')
                    key.erase(key.begin());
                while (!key.empty() && key.back() == ' ')
                    key.pop_back();

                if (key.empty()) {
                    // ✅ أعد الحالة إذا المفتاح فارغ
                    LoginState::g_IsChecking.store(false);
                    std::lock_guard<std::mutex> lk(LoginState::g_Mtx);
                    LoginState::g_StatusMsg = "[ Enter Key First ]";
                    LoginState::g_StatusOK  = false;
                } else {
                    {
                        std::lock_guard<std::mutex> lk(LoginState::g_Mtx);
                        LoginState::g_StatusMsg = "[ Checking... ]";
                        LoginState::g_StatusOK  = true;
                    }
                    std::string devId = getDeviceId();
                    std::thread([key, devId]() {
                        doLoginRequest(key, devId);
                    }).detach();
                }
            }
        }
    }

    // ✅ FIX: Pop قبل End
    ImGui::PopStyleVar(4);
    ImGui::PopStyleColor(8);
    ImGui::End();
}

// ════════════════════════════════════════════════════════════════════
//  API
// ════════════════════════════════════════════════════════════════════
inline bool IsUserLoggedIn() {
    return LoginState::g_IsLoggedIn.load();
}

inline void RenderLoginWindow(int w, int h) {
    DrawLoginWindow(w, h);
}
