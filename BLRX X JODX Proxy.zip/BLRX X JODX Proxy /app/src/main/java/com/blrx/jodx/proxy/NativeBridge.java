package com.blrx.jodx.proxy;

public class NativeBridge {
    static {
        try {
            System.loadLibrary("blrxpanel");
        } catch (UnsatisfiedLinkError ignored) {
        }
    }

    public native void initialize();
    public native void setFeatureState(String feature, boolean enabled);
    public native String getStatus();
}
