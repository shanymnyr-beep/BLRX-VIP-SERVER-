package com.blrx.jodx.proxy;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String PREFS = "blrx_panel_prefs";
    private static final String KEY_LAST_KEY = "last_key";
    private static final String KEY_REMEMBER = "remember";
    private static final String KEY_AUTO = "auto";
    private static final String KEY_LOGGED = "logged";

    private ViewGroup root;
    private View splashView;
    private View loginView;
    private View shizukuView;
    private View panelView;
    private EditText keyInput;
    private CheckBox rememberBox;
    private CheckBox autoBox;
    private TextView statusText;
    private SharedPreferences prefs;
    private NativeBridge nativeBridge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        root = findViewById(R.id.root_container);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        nativeBridge = new NativeBridge();
        buildViews();
        showSplash();
    }

    private void buildViews() {
        splashView = buildSplashView();
        loginView = buildLoginView();
        shizukuView = buildShizukuView();
        panelView = buildPanelView();
        root.addView(splashView);
        root.addView(loginView);
        root.addView(shizukuView);
        root.addView(panelView);
        loginView.setVisibility(View.GONE);
        shizukuView.setVisibility(View.GONE);
        panelView.setVisibility(View.GONE);
    }

    private View buildSplashView() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(32, 32, 32, 32);
        layout.setBackgroundColor(Color.parseColor("#06070C"));

        TextView title = new TextView(this);
        title.setText(R.string.splash_title);
        title.setTextSize(24f);
        title.setTextColor(Color.WHITE);
        title.setPadding(0, 0, 0, 8);

        TextView subtitle = new TextView(this);
        subtitle.setText(R.string.splash_subtitle);
        subtitle.setTextColor(Color.parseColor("#9CA3AF"));
        subtitle.setTextSize(16f);

        layout.addView(title);
        layout.addView(subtitle);
        return layout;
    }

    private View buildLoginView() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(32, 32, 32, 32);
        layout.setBackgroundColor(Color.parseColor("#06070C"));

        TextView title = new TextView(this);
        title.setText("Secure Login");
        title.setTextSize(22f);
        title.setTextColor(Color.WHITE);
        title.setPadding(0, 0, 0, 16);

        keyInput = new EditText(this);
        keyInput.setHint(R.string.login_hint);
        keyInput.setTextColor(Color.WHITE);
        keyInput.setHintTextColor(Color.parseColor("#9CA3AF"));
        keyInput.setBackgroundColor(Color.parseColor("#111827"));
        keyInput.setPadding(20, 20, 20, 20);
        keyInput.setSingleLine(true);

        Button loginButton = new Button(this);
        loginButton.setText(R.string.login_button);
        loginButton.setOnClickListener(v -> performLogin());

        rememberBox = new CheckBox(this);
        rememberBox.setText(R.string.remember_key);
        rememberBox.setTextColor(Color.WHITE);

        autoBox = new CheckBox(this);
        autoBox.setText(R.string.auto_login);
        autoBox.setTextColor(Color.WHITE);

        statusText = new TextView(this);
        statusText.setTextColor(Color.parseColor("#9CA3AF"));
        statusText.setPadding(0, 16, 0, 0);

        layout.addView(title);
        layout.addView(keyInput);
        layout.addView(loginButton);
        layout.addView(rememberBox);
        layout.addView(autoBox);
        layout.addView(statusText);

        if (prefs.getBoolean(KEY_REMEMBER, false)) {
            keyInput.setText(prefs.getString(KEY_LAST_KEY, ""));
            rememberBox.setChecked(true);
        }
        if (prefs.getBoolean(KEY_AUTO, false) && prefs.getBoolean(KEY_LOGGED, false)) {
            autoBox.setChecked(true);
            performLogin();
        }

        return layout;
    }

    private View buildShizukuView() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(32, 32, 32, 32);
        layout.setBackgroundColor(Color.parseColor("#06070C"));

        TextView title = new TextView(this);
        title.setText("Shizuku Check");
        title.setTextSize(22f);
        title.setTextColor(Color.WHITE);
        title.setPadding(0, 0, 0, 12);

        TextView info = new TextView(this);
        info.setTextColor(Color.parseColor("#9CA3AF"));
        info.setText("Checking the Shizuku environment...");

        Button connectButton = new Button(this);
        connectButton.setText(R.string.shizuku_connect);
        connectButton.setOnClickListener(v -> {
            statusText.setText("Shizuku Connected Successfully");
            statusText.setTextColor(Color.parseColor("#10B981"));
            showPanel();
        });

        layout.addView(title);
        layout.addView(info);
        layout.addView(connectButton);
        return layout;
    }

    private View buildPanelView() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(Color.parseColor("#06070C"));

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(24, 24, 24, 24);

        TextView title = new TextView(this);
        title.setText("BLRX Panel");
        title.setTextSize(24f);
        title.setTextColor(Color.WHITE);
        title.setPadding(0, 0, 0, 12);

        TextView subtitle = new TextView(this);
        subtitle.setText("Native hooks and panel controls");
        subtitle.setTextColor(Color.parseColor("#9CA3AF"));

        Button startButton = new Button(this);
        startButton.setText(R.string.start_panel);
        startButton.setOnClickListener(v -> startPanel());

        Button stopButton = new Button(this);
        stopButton.setText(R.string.stop_panel);
        stopButton.setOnClickListener(v -> stopPanel());

        addSwitch(layout, "Hook A", "hook_a");
        addSwitch(layout, "Hook B", "hook_b");
        addSwitch(layout, "Memory Patch", "memory_patch");
        addSwitch(layout, "Overlay", "overlay");

        layout.addView(title);
        layout.addView(subtitle);
        layout.addView(startButton);
        layout.addView(stopButton);
        scrollView.addView(layout);
        return scrollView;
    }

    private void addSwitch(LinearLayout parent, String label, String feature) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, 12, 0, 12);

        TextView textView = new TextView(this);
        textView.setText(label);
        textView.setTextColor(Color.WHITE);
        textView.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        Switch switchView = new Switch(this);
        switchView.setOnCheckedChangeListener((buttonView, isChecked) -> {
            nativeBridge.setFeatureState(feature, isChecked);
            Toast.makeText(this, label + " -> " + isChecked, Toast.LENGTH_SHORT).show();
        });

        row.addView(textView);
        row.addView(switchView);
        parent.addView(row);
    }

    private void showSplash() {
        setAllHidden();
        splashView.setVisibility(View.VISIBLE);
        new Handler().postDelayed(this::showLogin, 2200);
    }

    private void showLogin() {
        setAllHidden();
        loginView.setVisibility(View.VISIBLE);
    }

    private void showShizuku() {
        setAllHidden();
        shizukuView.setVisibility(View.VISIBLE);
    }

    private void showPanel() {
        setAllHidden();
        panelView.setVisibility(View.VISIBLE);
    }

    private void setAllHidden() {
        splashView.setVisibility(View.GONE);
        loginView.setVisibility(View.GONE);
        shizukuView.setVisibility(View.GONE);
        panelView.setVisibility(View.GONE);
    }

    private void performLogin() {
        String inputKey = keyInput.getText().toString().trim();
        if (isValidKey(inputKey)) {
            prefs.edit().putBoolean(KEY_LOGGED, true).putString(KEY_LAST_KEY, inputKey).putBoolean(KEY_REMEMBER, rememberBox.isChecked()).putBoolean(KEY_AUTO, autoBox.isChecked()).apply();
            statusText.setTextColor(Color.parseColor("#10B981"));
            statusText.setText("Login successful");
            showShizuku();
        } else {
            statusText.setTextColor(Color.parseColor("#EF4444"));
            statusText.setText("Invalid key. Please try again.");
        }
    }

    private boolean isValidKey(String key) {
        if (TextUtils.isEmpty(key)) {
            return false;
        }
        String[] validKeys = {
                decodeKey("BLRX-JODX-1105"),
                decodeKey("BLRX-MOD-0808")
        };
        for (String valid : validKeys) {
            if (valid.equals(key)) {
                return true;
            }
        }
        return false;
    }

    private String decodeKey(String encoded) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < encoded.length(); i++) {
            char c = encoded.charAt(i);
            builder.append((char) (c + 1));
        }
        return builder.toString();
    }

    private void startPanel() {
        startService(new Intent(this, PanelFloatingService.class));
        nativeBridge.initialize();
        nativeBridge.setFeatureState("bootstrap", true);
        Toast.makeText(this, "Panel started", Toast.LENGTH_SHORT).show();
    }

    private void stopPanel() {
        stopService(new Intent(this, PanelFloatingService.class));
        Toast.makeText(this, "Panel stopped", Toast.LENGTH_SHORT).show();
    }
}
