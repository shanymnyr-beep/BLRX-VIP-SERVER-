#ifndef RENDERER_H
#define RENDERER_H
void rendererInitialize();
#endif
