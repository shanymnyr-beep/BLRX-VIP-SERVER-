#include "renderer.h"
#include <android/log.h>

void rendererInitialize() {
    __android_log_print(ANDROID_LOG_INFO, "BLRX", "Renderer initialized");
}
