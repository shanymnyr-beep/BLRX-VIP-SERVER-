LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := blrxpanel
LOCAL_SRC_FILES :=     main.cpp     hook.cpp     gui.cpp     renderer.cpp
LOCAL_LDLIBS := -llog -landroid
include $(BUILD_SHARED_LIBRARY)
