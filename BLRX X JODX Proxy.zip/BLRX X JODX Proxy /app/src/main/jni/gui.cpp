#include "gui.h"
#include <android/log.h>

void guiInitialize() {
    __android_log_print(ANDROID_LOG_INFO, "BLRX", "GUI layer initialized");
}
