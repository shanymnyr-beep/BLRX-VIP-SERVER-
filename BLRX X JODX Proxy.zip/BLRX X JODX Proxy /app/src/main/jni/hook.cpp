#include "hook.h"
#include <android/log.h>

void hookInitialize() {
    __android_log_print(ANDROID_LOG_INFO, "BLRX", "Hook engine initialized");
}
