#include <jni.h>
#include <string>
#include <android/log.h>

extern "C" {
JNIEXPORT void JNICALL Java_com_blrx_jodx_proxy_NativeBridge_initialize(JNIEnv* env, jobject thiz) {
    __android_log_print(ANDROID_LOG_INFO, "BLRX", "Native bridge initialized");
}

JNIEXPORT void JNICALL Java_com_blrx_jodx_proxy_NativeBridge_setFeatureState(JNIEnv* env, jobject thiz, jstring feature, jboolean enabled) {
    const char* featureName = env->GetStringUTFChars(feature, nullptr);
    __android_log_print(ANDROID_LOG_INFO, "BLRX", "Feature %s -> %d", featureName, enabled);
    env->ReleaseStringUTFChars(feature, featureName);
}

JNIEXPORT jstring JNICALL Java_com_blrx_jodx_proxy_NativeBridge_getStatus(JNIEnv* env, jobject thiz) {
    return env->NewStringUTF("BLRX native bridge ready");
}
}
